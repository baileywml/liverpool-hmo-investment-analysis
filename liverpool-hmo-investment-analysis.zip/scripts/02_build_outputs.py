from __future__ import annotations
import os
from pathlib import Path

import pandas as pd
from dotenv import dotenv_values

from src.ppd.ppd_2025 import PpdFilters, read_ppd_2025, filter_liverpool_2025, aggregate_prices_by_outcode
from src.census.ts068 import extract_ts068_lsoa, build_student_density
from src.utils.postcodesio import bulk_lookup_lsoa

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "settings.env"

def main() -> None:
    if not CONFIG.exists():
        raise FileNotFoundError(
            f"Missing {CONFIG}. Copy config/settings.example.env -> config/settings.env and edit if needed."
        )

    cfg = dotenv_values(CONFIG)

    raw_ppd = ROOT / "data" / "raw" / "land_registry" / "pp-2025.csv"
    raw_ts068_zip = ROOT / "data" / "raw" / "ons" / "census2021-ts068.zip"

    if not raw_ppd.exists():
        raise FileNotFoundError(f"Missing {raw_ppd}. Run scripts/01_download_data.py first.")
    if not raw_ts068_zip.exists():
        raise FileNotFoundError(f"Missing {raw_ts068_zip}. Run scripts/01_download_data.py first.")

    outputs = ROOT / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)

    # --- Prices (Liverpool, 2025) ---
    df_ppd = read_ppd_2025(raw_ppd)
    df_liv = filter_liverpool_2025(df_ppd, PpdFilters(district=cfg.get("PPD_DISTRICT_FILTER","LIVERPOOL"), year=2025))

    # Always produce an outcode summary (fast, no extra lookups)
    out_outcode = aggregate_prices_by_outcode(df_liv)
    out_outcode.to_csv(outputs / "prices_liverpool_2025_by_outcode.csv", index=False)
    print("Wrote outputs/prices_liverpool_2025_by_outcode.csv")

    # Optional: LSOA mapping via postcodes.io (rate-limited + cached)
    # This step can take time depending on how many unique postcodes appear in Liverpool 2025 transactions.
    use_onspd = str(cfg.get("USE_ONSPD","0")).strip() == "1"

    if not use_onspd:
        unique_postcodes = sorted({p for p in df_liv["postcode"].dropna().unique().tolist() if isinstance(p, str) and p.strip()})
        cache_path = ROOT / "data" / "processed" / "postcode_cache_postcodesio.json"
        sleep_s = float(cfg.get("POSTCODESIO_SLEEP_SECONDS","0.25"))
        max_retries = int(cfg.get("POSTCODESIO_MAX_RETRIES","5"))

        print(f"Mapping {len(unique_postcodes)} unique postcodes to LSOA via postcodes.io (cached)...")
        mapping = bulk_lookup_lsoa(unique_postcodes, cache_path=cache_path, sleep_seconds=sleep_s, max_retries=max_retries)

        # apply mapping
        norm = df_liv["postcode"].astype(str).str.upper().str.replace(" ", "", regex=False)
        df_liv["lsoa_name"] = norm.map(mapping)

        # Keep only rows with LSOA found
        df_lsoa = df_liv.dropna(subset=["lsoa_name"]).copy()
        g = df_lsoa.groupby("lsoa_name")["price"]
        out_lsoa = pd.DataFrame({
            "lsoa_name": g.size().index,
            "sales_count": g.size().values,
            "median_price": g.median().values,
            "p25_price": g.quantile(0.25).values,
            "p75_price": g.quantile(0.75).values,
            "mean_price": g.mean().values,
        }).sort_values("median_price", ascending=True)

        out_lsoa.to_csv(outputs / "prices_liverpool_2025_by_lsoa_name.csv", index=False)
        print("Wrote outputs/prices_liverpool_2025_by_lsoa_name.csv")
    else:
        print("USE_ONSPD=1 selected, but ONSPD parsing is not implemented in this starter. Use postcodes.io mapping or add ONSPD support as an extension.")

    # --- Student density (TS068, LSOA) ---
    processed = ROOT / "data" / "processed"
    processed.mkdir(parents=True, exist_ok=True)

    lsoa_file = processed / "ts068_lsoa.csv"
    extract_ts068_lsoa(raw_ts068_zip, lsoa_file)

    out_students = outputs / "student_density_by_lsoa.csv"
    build_student_density(lsoa_file, out_students)
    print("Wrote outputs/student_density_by_lsoa.csv")

    print("Done.")

if __name__ == "__main__":
    main()
