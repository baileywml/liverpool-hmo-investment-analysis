from __future__ import annotations
import os
from pathlib import Path

from dotenv import dotenv_values

from src.utils.io import download_file

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "settings.env"

def main() -> None:
    if not CONFIG.exists():
        raise FileNotFoundError(
            f"Missing {CONFIG}. Copy config/settings.example.env -> config/settings.env and edit if needed."
        )

    cfg = dotenv_values(CONFIG)

    raw = ROOT / "data" / "raw"
    raw.mkdir(parents=True, exist_ok=True)

    ppd_url = cfg.get("PPD_2025_URL")
    ts068_url = cfg.get("NOMIS_TS068_URL")

    if not ppd_url or not ts068_url:
        raise ValueError("PPD_2025_URL and NOMIS_TS068_URL must be set in config/settings.env")

    print("Downloading PPD 2025...")
    download_file(ppd_url, raw / "land_registry" / "pp-2025.csv", retries=6)

    print("Downloading Census 2021 TS068 bulk zip...")
    download_file(ts068_url, raw / "ons" / "census2021-ts068.zip", retries=6)

    print("Done. Raw data saved under data/raw/")

if __name__ == "__main__":
    main()
