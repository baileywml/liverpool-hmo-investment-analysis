Put your **manual** listings snapshot here (no scraping).

Create a file like:
- `listings_snapshot_liverpool_2025-xx-xx.csv`

Suggested columns:
- captured_date
- source (e.g., 'manual_rightmove', 'manual_spare_room')
- postcode
- bedrooms
- monthly_rent_total (or rent_per_room)
- notes

Keep it small (e.g., 50–200 rows) and document how you collected it.
