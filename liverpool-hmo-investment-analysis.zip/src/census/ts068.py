from __future__ import annotations
from pathlib import Path
import zipfile
import pandas as pd

def extract_ts068_lsoa(zip_path: str | Path, out_csv: str | Path) -> Path:
    """Extract TS068 LSOA-level file from the Nomis bulk zip (if present).
    The zip contains multiple CSVs for different geographies; we look for an LSOA file.
    """
    zip_path = Path(zip_path)
    out_csv = Path(out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path) as z:
        # heuristic: find the LSOA file
        candidates = [n for n in z.namelist() if "LSOA" in n.upper() and n.lower().endswith(".csv")]
        if not candidates:
            raise FileNotFoundError("No LSOA CSV found in TS068 zip. Try downloading from ONS directly.")
        # pick first candidate
        name = sorted(candidates)[0]
        with z.open(name) as f, open(out_csv, "wb") as out:
            out.write(f.read())
    return out_csv

def build_student_density(lsoa_csv: str | Path, out_csv: str | Path) -> Path:
    """Build a simple student density table from TS068 LSOA file.
    The exact column names can vary by release packaging, so we detect likely columns.
    """
    df = pd.read_csv(lsoa_csv)

    # Standard columns typically include geography code/name and counts by category.
    # We'll try common patterns and fail with a helpful message if not found.
    geo_code_col = next((c for c in df.columns if "geography code" in c.lower() or c.lower() in {"geography code", "geography_code"}), None)
    if geo_code_col is None:
        # fall back: first column
        geo_code_col = df.columns[0]

    # Find student and total columns
    student_col = next((c for c in df.columns if "student" == c.lower().strip() or "student" in c.lower()), None)
    total_col = next((c for c in df.columns if "total" in c.lower() and "number" in c.lower() or c.lower().strip() == "total"), None)

    if student_col is None:
        # Some releases label as "Student" under a dimension; last resort: search for exact "Student" column
        student_col = next((c for c in df.columns if c.strip().lower() == "student"), None)

    if student_col is None:
        raise KeyError(f"Could not find a student column in TS068 LSOA file. Columns: {list(df.columns)[:25]} ...")

    # If total not present, approximate total = sum numeric columns
    if total_col is None:
        numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        if student_col in numeric_cols:
            total_series = df[numeric_cols].sum(axis=1)
        else:
            total_series = df.select_dtypes("number").sum(axis=1)
    else:
        total_series = df[total_col]

    out = pd.DataFrame({
        "lsoa_code": df[geo_code_col].astype(str),
        "students": df[student_col].fillna(0).astype(float),
        "total": total_series.fillna(0).astype(float),
    })
    out["student_pct"] = (out["students"] / out["total"]).where(out["total"] > 0, 0.0)

    out_csv = Path(out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_csv, index=False)
    return out_csv
