from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import pandas as pd

PPD_COLUMNS = [
    "transaction_unique_identifier",
    "price",
    "date_of_transfer",
    "postcode",
    "property_type",
    "old_new",
    "duration",
    "paon",
    "saon",
    "street",
    "locality",
    "town_city",
    "district",
    "county",
    "ppd_category_type",
    "record_status",
]

@dataclass(frozen=True)
class PpdFilters:
    district: str = "LIVERPOOL"
    year: int = 2025

def read_ppd_2025(path: str | Path) -> pd.DataFrame:
    """Read the 2025 PPD yearly CSV into a DataFrame with stable dtypes."""
    df = pd.read_csv(
        path,
        header=None,
        names=PPD_COLUMNS,
        dtype={
            "transaction_unique_identifier": "string",
            "price": "Int64",
            "date_of_transfer": "string",
            "postcode": "string",
            "property_type": "string",
            "old_new": "string",
            "duration": "string",
            "paon": "string",
            "saon": "string",
            "street": "string",
            "locality": "string",
            "town_city": "string",
            "district": "string",
            "county": "string",
            "ppd_category_type": "string",
            "record_status": "string",
        },
    )
    # standardise postcodes
    df["postcode"] = df["postcode"].str.strip().str.upper()
    return df

def filter_liverpool_2025(df: pd.DataFrame, filters: PpdFilters) -> pd.DataFrame:
    out = df.copy()

    # filter district (PPD district is not LAD code, but is very useful for a first pass)
    out = out[out["district"].str.upper() == filters.district.upper()]

    # ensure year filter
    out["date_of_transfer"] = pd.to_datetime(out["date_of_transfer"], errors="coerce")
    out = out[out["date_of_transfer"].dt.year == filters.year]

    # drop missing/invalid prices
    out = out[out["price"].notna() & (out["price"] > 0)]

    # add outcode (first part of postcode)
    out["outcode"] = out["postcode"].str.extract(r"^([A-Z]{1,2}\d{1,2})", expand=False)
    return out

def aggregate_prices_by_outcode(df_liv: pd.DataFrame) -> pd.DataFrame:
    g = df_liv.groupby("outcode", dropna=True)["price"]
    out = pd.DataFrame({
        "sales_count": g.size(),
        "median_price": g.median(),
        "p25_price": g.quantile(0.25),
        "p75_price": g.quantile(0.75),
        "mean_price": g.mean(),
    }).reset_index().sort_values(["median_price"], ascending=True)
    return out
