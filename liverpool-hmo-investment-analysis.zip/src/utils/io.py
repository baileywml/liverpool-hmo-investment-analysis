from __future__ import annotations
import hashlib
import os
import time
from pathlib import Path
from typing import Optional

import requests

def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def download_file(url: str, dest: str | Path, *, timeout: int = 60, retries: int = 5) -> Path:
    """Download with basic retry/backoff.
    This is written to be robust on home broadband and CI runners.
    """
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)

    backoff = 2
    last_err: Optional[Exception] = None

    for attempt in range(1, retries + 1):
        try:
            with requests.get(url, stream=True, timeout=timeout) as r:
                r.raise_for_status()
                tmp = dest.with_suffix(dest.suffix + ".part")
                with open(tmp, "wb") as f:
                    for chunk in r.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            f.write(chunk)
                tmp.replace(dest)
                return dest
        except Exception as e:
            last_err = e
            time.sleep(backoff)
            backoff *= 2

    raise RuntimeError(f"Failed to download {url} after {retries} attempts") from last_err
