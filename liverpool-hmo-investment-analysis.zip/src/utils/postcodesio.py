from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import requests

POSTCODESIO_BULK = "https://api.postcodes.io/postcodes"

def _normalise_postcode(pc: str) -> str:
    return pc.strip().upper().replace(" ", "")

def bulk_lookup_lsoa(postcodes: List[str], *, cache_path: Path, sleep_seconds: float = 0.25,
                     max_retries: int = 5) -> Dict[str, Optional[str]]:
    """Resolve postcodes -> LSOA using postcodes.io in batches.
    Caches results to disk to avoid repeated API calls.
    Returns dict: normalised_postcode -> LSOA name (or None).
    """
    cache_path.parent.mkdir(parents=True, exist_ok=True)

    cache: Dict[str, Optional[str]] = {}
    if cache_path.exists():
        cache = json.loads(cache_path.read_text(encoding="utf-8"))

    needed = [_normalise_postcode(p) for p in postcodes if _normalise_postcode(p) not in cache]
    out: Dict[str, Optional[str]] = dict(cache)

    if not needed:
        return out

    # postcodes.io accepts up to 100 in one request
    for i in range(0, len(needed), 100):
        batch = needed[i:i+100]
        payload = {"postcodes": batch}

        err: Optional[Exception] = None
        for attempt in range(1, max_retries + 1):
            try:
                resp = requests.post(POSTCODESIO_BULK, json=payload, timeout=30)
                resp.raise_for_status()
                data = resp.json()
                for item in data.get("result", []):
                    query = item.get("query")
                    result = item.get("result") or {}
                    lsoa = result.get("lsoa")
                    if query is not None:
                        out[_normalise_postcode(query)] = lsoa
                break
            except Exception as e:
                err = e
                time.sleep(1.5 * attempt)
        else:
            raise RuntimeError("postcodes.io lookup failed") from err

        # polite pause
        time.sleep(sleep_seconds)

        # save incremental cache
        cache_path.write_text(json.dumps(out), encoding="utf-8")

    return out
