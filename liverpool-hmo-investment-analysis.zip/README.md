# Liverpool HMO Investment Analysis (Cash Purchase, Student Market)

This repository is an end-to-end **data analytics project** that evaluates student-focused HMO opportunities in Liverpool using **2025 purchase transactions** plus open demographic data.

> **No mortgages** are modelled. The investment is assumed to be bought outright and then rented to students.

## What this project produces
- Cleaned **2025** sale transactions for Liverpool (HM Land Registry Price Paid Data)
- Student-density proxies (Census 2021 – *Schoolchildren and full-time students*)
- A repeatable data pipeline that outputs:
  - `outputs/prices_liverpool_2025_by_lsoa.csv` (if LSOA mapping enabled)
  - `outputs/prices_liverpool_2025_by_outcode.csv` (fallback)
  - `outputs/student_density_by_lsoa.csv`
- (Next milestone) ROI model + interactive dashboard

## Data sources (open)
- **HM Land Registry Price Paid Data (PPD), 2025 yearly file** (England & Wales).  
  Contains HM Land Registry data © Crown copyright and database right. Licensed under OGL v3.0.  
- **ONS Census 2021: TS068 Schoolchildren and full-time students** (LSOA level).

**Important notes**
- Property portal listing data (Rightmove/Zoopla etc.) is *not* scraped here. If you want a supply snapshot, add your own manually captured CSV to `data/raw/listings_snapshot/` and keep it small.

## Quickstart

### 1) Create a virtual environment
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2) Download & build outputs
```bash
python scripts/01_download_data.py
python scripts/02_build_outputs.py
```

Outputs will appear in `outputs/`.

## LSOA mapping options (choose one)
This project can map sale postcodes to LSOAs in two ways:

1) **Postcodes.io API (default)**  
   - No giant lookup file needed
   - Includes caching + rate limiting
   - Best for a portfolio project
2) **ONSPD lookup (optional)**  
   - Faster at scale but large (~2.3GB)
   - If you download it, set `USE_ONSPD=1`

See `config/settings.example.env`.

## Repo structure
```
data/
  raw/                 # raw downloads (not committed)
  processed/           # intermediate files (not committed)
outputs/               # final CSV outputs (committed optional)
scripts/               # runnable scripts
src/                   # reusable modules
```

## Attribution
When publishing any results that use PPD data, include the attribution statement required by HM Land Registry.

## License
Code: MIT (see `LICENSE`).  
Data: follow each dataset’s license and usage conditions.
